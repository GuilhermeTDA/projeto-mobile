export type INotas = {
    id: string,
    titulo: string,
    descricao: string,
    created_at: Date,
}
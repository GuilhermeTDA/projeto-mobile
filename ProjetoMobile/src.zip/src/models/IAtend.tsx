export type IAtend = {
    id: string,
    data: string,
    hora: string,
    descricao: string,
}
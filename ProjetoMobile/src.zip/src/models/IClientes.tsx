export type IClientes = {
    id:string,
    nome:string,
    cpf:string,
    rua:string,
    numero: string,
    bairro:string,
    complemento:string,
    cidade:string,
    estado:string,
    dataNasc:string,
}
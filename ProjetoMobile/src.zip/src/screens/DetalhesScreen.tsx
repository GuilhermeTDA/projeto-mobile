import { Text, View } from 'react-native';

const DetalhesScreen = () => {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>Detalhes Screen</Text>
      </View>
    );
     
  }

  export default DetalhesScreen;
import { Text, View, StyleSheet, Pressable } from 'react-native';
import { LoginProps } from '../types';



const ex2 = ({ navigation, route }: LoginProps) => {

    return (
        <View>
            <Pressable style={styles.botao} onPress={() => navigation.navigate('Exercicio1')}>

                <Text style={{ fontSize: 15 }}>exercicio 1</Text>
            </Pressable>

            <Pressable style={styles.botao} onPress={() => navigation.navigate('Exercicio3')}>

                <Text style={{ fontSize: 15 }}>exercicio 3</Text>
            </Pressable>
        </View>

    )
}

export default ex2;


const styles = StyleSheet.create({
    botao: {
        width: 80,
        height: 40,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 5,
        backgroundColor: '#d4d0cf',
        marginBottom: 20,
        alignItems: 'center',
        justifyContent: 'center',
    },
});
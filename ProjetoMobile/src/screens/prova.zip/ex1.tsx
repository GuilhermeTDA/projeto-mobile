import { Text } from 'react-native';


const ex1 = () => {

    return (

        <Text>teste</Text>

    )
}

export default ex1;

